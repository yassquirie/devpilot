# Contributing to DevPilot

Small, well-tested improvements are welcome. Discuss substantial behavior or score
changes in an issue before implementation. Search existing issues and pull
requests first. Follow the [code of conduct](CODE_OF_CONDUCT.md).

## Development setup

Use Python 3.11+ and create an environment in your checkout:

```bash
python -m venv .venv
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
```

Keep business logic in the analyzer modules and presentation in `cli/` and
`reporting/`. Follow type annotations, meaningful public docstrings, and Ruff
formatting. Prefer the standard library unless a dependency removes substantial
complexity. See [architecture](docs/architecture.md).

## Required checks

```bash
python -m ruff check .
python -m ruff format --check .
python -m pytest --cov=devpilot --cov-report=term-missing
python -m build
```

CI runs lint and formatting, tests on Ubuntu for Python 3.11–3.14, Windows tests
on 3.13, and a wheel install/entry-point smoke check. Tests never query public PyPI;
fake metadata and injected lookup functions cover online behavior. Use real Ruff
for CLI integration. Git tests require Git; symlink tests can skip when OS
permissions prevent creation.

## Pull requests

- Describe the user-visible trigger, resulting behavior, and validation.
- Test observed behavior, meaningful failure paths, and redaction for sensitive
  checks. Do not add real credentials or private project data to fixtures.
- Document new rule IDs, false positives, scope limits, and scoring implications.
- Preserve report compatibility or deliberately bump the schema version.
- Keep related changes focused and update examples if output behavior changes.

## Bug reports

Include OS, Python version, DevPilot version, the command, expected behavior, and a
minimal synthetic repository that reproduces the issue. Review reports before
attaching them: names and paths can be sensitive metadata. Security reports follow
[SECURITY.md](SECURITY.md), not public issue reproduction instructions.

## Release checklist

Update the package version and `devpilot.__version__` together, regenerate sample
reports, run all checks, build a clean wheel and source archive, and install the
wheel into an empty environment. Confirm registry name availability and configure
project URLs and private security reporting before public publication. Publishing
and registry credentials are intentionally outside CI in this starter release.
