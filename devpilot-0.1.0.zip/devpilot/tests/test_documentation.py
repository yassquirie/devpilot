"""Documentation presence and installation signal checks."""

from devpilot.documentation.analyzer import analyze_documentation
from devpilot.scanner.project import inspect_project


def test_healthy_documentation(project):
    assert not analyze_documentation(inspect_project(project)).findings


def test_missing_documents(tmp_path):
    result = analyze_documentation(inspect_project(tmp_path))
    assert {f.rule for f in result.findings} == {"DOC_README", "DOC_LICENSE", "DOC_CONTRIBUTING"}


def test_case_insensitive_names_and_missing_installation(project):
    (project / "README.md").write_text("# Sample\nPurpose only.\n")
    (project / "CONTRIBUTING.md").unlink()
    (project / ".github").mkdir()
    (project / ".github" / "CONTRIBUTING.md").write_text("Run tests")
    result = analyze_documentation(inspect_project(project))
    assert [f.rule for f in result.findings] == ["DOC_INSTALL"]


def test_unreadable_readme_is_partial(project):
    (project / "README.md").write_bytes(b"\xff")
    assert analyze_documentation(inspect_project(project)).status == "partial"
