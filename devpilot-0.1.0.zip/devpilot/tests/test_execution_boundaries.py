"""A scan must not run repository-local tools or filesystem-monitor hooks."""

from pathlib import Path
from types import SimpleNamespace

from devpilot.quality.ruff import analyze_quality
from devpilot.scanner.project import _git_files, inspect_project


def test_ruff_is_not_shadowed_by_repository_module(project, monkeypatch):
    (project / "ruff.py").write_text('raise RuntimeError("Repository code executed")\n')
    monkeypatch.chdir(project)
    result = analyze_quality(inspect_project(project))
    assert result.status == "complete"


def test_git_does_not_use_repository_executable(project, monkeypatch):
    monkeypatch.setattr("devpilot.scanner.project.shutil.which", lambda _: str(project / "git.exe"))

    def forbidden(*args, **kwargs):
        raise AssertionError("Repository executable must not run")

    monkeypatch.setattr("devpilot.scanner.project.subprocess.run", forbidden)
    assert _git_files(project) is None


def test_git_disables_fsmonitor(project, tmp_path_factory, monkeypatch):
    executable = tmp_path_factory.mktemp("trusted") / "git.exe"
    calls = []
    monkeypatch.setattr("devpilot.scanner.project.shutil.which", lambda _: str(executable))

    def fake(command, **kwargs):
        calls.append(command)
        return SimpleNamespace(returncode=0, stdout=b"app.py\0")

    monkeypatch.setattr("devpilot.scanner.project.subprocess.run", fake)
    assert _git_files(project) == ({"app.py"}, {"app.py"})
    assert all(
        command[:3] == [str(Path(executable).resolve()), "-c", "core.fsmonitor=false"]
        for command in calls
    )
