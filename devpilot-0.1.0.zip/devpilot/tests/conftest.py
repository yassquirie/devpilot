"""Reusable real-directory fixtures, with no network access."""

from pathlib import Path

import pytest


@pytest.fixture
def project(tmp_path: Path) -> Path:
    """A small healthy Python project for analyzer and CLI integration tests."""
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "sample"\nversion = "0.1.0"\nrequires-python = ">=3.11"\n',
        encoding="utf-8",
    )
    (tmp_path / "README.md").write_text(
        "# Sample\n\n## Installation\n\npip install .\n", encoding="utf-8"
    )
    (tmp_path / "LICENSE").write_text("MIT License\n", encoding="utf-8")
    (tmp_path / "CONTRIBUTING.md").write_text("Run pytest.\n", encoding="utf-8")
    (tmp_path / "app.py").write_text('"""Sample module."""\n\nVALUE = 1\n', encoding="utf-8")
    (tmp_path / "tests").mkdir()
    (tmp_path / "tests" / "test_app.py").write_text(
        "def test_ok():\n    assert True\n", encoding="utf-8"
    )
    return tmp_path
