"""Score math and format escaping are independent from analyzer execution."""

from devpilot.models import CheckResult, Finding
from devpilot.reporting.render import render_markdown, safe_text, serialize
from devpilot.reporting.score import calculate_score
from devpilot.service import build_report


def finding(severity="high"):
    return Finding(rule="TEST", severity=severity, message="Review", suggestion="Fix")


def test_scoring_cap_normalization_and_provisional():
    checks = [
        CheckResult(category="quality", findings=[finding()] * 4),
        CheckResult(category="documentation"),
    ]
    score = calculate_score(checks)
    assert score.value == 40  # 20 earned of 50 available
    assert score.parts[0].deducted == 30
    checks[0].status = "partial"
    assert calculate_score(checks).provisional
    checks[0].status = "skipped"
    assert calculate_score(checks).value == 100
    assert calculate_score([CheckResult(category="quality", status="skipped")]).value is None


def test_score_is_not_provisional_on_full_healthy_scan(project):
    report = build_report(project)
    assert report.score.value == 100
    assert not report.score.provisional
    assert sum(p.available for p in report.score.parts) == 100


def test_reports_escape_untrusted_names(project):
    report = build_report(project, mode="security")
    report.inventory.project_name = "<script>alert(1)</script>|\x1b[31m"
    markdown = render_markdown(report)
    assert "<script>" not in markdown
    assert "\\|" in markdown
    assert "\x1b" not in markdown
    assert "schema_version" in serialize(report, "json")
    assert safe_text("a\nb") == r"a\x0ab"


def test_incomplete_inventory_affects_score(project):
    report = build_report(project, max_files=1)
    assert report.score.provisional
    assert any(c.status == "partial" for c in report.checks)
