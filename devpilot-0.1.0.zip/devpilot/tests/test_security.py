"""Security heuristics, explicit redaction, and Git index context."""

from devpilot.scanner.project import inspect_project
from devpilot.security.secrets import analyze_security


def test_redaction_of_literals_and_private_keys(project):
    credential = "realish-" + "credential-987654321"
    (project / "settings.py").write_text(
        f'API_KEY = "{credential}"\nDEBUG = True\nverify=False\nALLOWED_HOSTS = ["*"]\n',
        encoding="utf-8",
    )
    (project / "private.pem").write_text("-----BEGIN " + "PRIVATE KEY-----\n")
    context = inspect_project(project)
    result = analyze_security(context)
    assert {f.rule for f in result.findings} == {
        "SECRET_LITERAL",
        "CONFIG_DEBUG",
        "CONFIG_TLS",
        "CONFIG_HOSTS",
    }
    assert credential not in result.model_dump_json()
    assert "REDACTED" in result.model_dump_json()
    assert all(f.path and f.line for f in result.findings)


def test_known_token_and_placeholder_handling(project):
    credential = "ghp_" + "a1B2c3" * 7
    (project / "settings.py").write_text(
        f"# leaked: {credential}\n"
        'API_KEY = "your_api_key_here"\nPASSWORD = "${SECRET_PASSWORD}"\n'
        'TOKEN = os.getenv("TOKEN")\n# DEBUG = True\n',
        encoding="utf-8",
    )
    result = analyze_security(inspect_project(project))
    assert len(result.findings) == 1
    assert result.findings[0].rule == "SECRET_LITERAL"
    assert credential not in result.model_dump_json()


def test_tracked_env_and_binary_limit(project):
    (project / ".env").write_text("SETTING=1")
    (project / "blob.txt").write_bytes(b"\x00bad")
    context = inspect_project(project)
    context.inventory.tracked_files.append(".env")
    result = analyze_security(context)
    assert result.status == "partial"
    assert any(f.rule == "SECRET_TRACKED_ENV" for f in result.findings)


def test_assignment_in_json_and_environment_file(project):
    value = "m4ybe" + "SensitiveValue123"
    (project / "config.json").write_text('{"password": "' + value + '"}')
    (project / ".env.local").write_text("ACCESS_TOKEN=" + value)
    result = analyze_security(inspect_project(project))
    assert len(result.findings) == 2
    assert value not in result.model_dump_json()
