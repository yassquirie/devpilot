"""Inventory boundaries, detection, ignore behavior, and failure modes."""

import shutil
import subprocess
from pathlib import Path

import pytest

from devpilot.scanner.project import ScanError, analyze_structure, inspect_project


@pytest.mark.parametrize("target", ["absent", "file.txt"])
def test_invalid_directory(tmp_path, target):
    (tmp_path / "file.txt").write_text("text")
    with pytest.raises(ScanError):
        inspect_project(tmp_path / target)


def test_inventory_and_exclusions(project):
    (project / ".venv").mkdir()
    (project / ".venv" / "hidden.py").write_text("pass")
    (project / "generated.py").write_text("pass")
    context = inspect_project(project, excludes=("generated*",))
    assert context.inventory.is_python
    assert context.inventory.source_files == 2
    assert "pyproject.toml" in context.inventory.config_files
    assert "tests" in context.inventory.top_level
    assert ".venv/hidden.py" not in context.inventory.files
    assert "generated.py" not in context.inventory.files
    assert not analyze_structure(context).findings


def test_non_python_and_no_test_detection(tmp_path):
    context = inspect_project(tmp_path)
    assert not context.inventory.is_python
    assert analyze_structure(context).findings[0].rule == "PROJECT_NOT_PYTHON"
    (tmp_path / "a.py").write_text("pass")
    rules = {f.rule for f in analyze_structure(inspect_project(tmp_path)).findings}
    assert rules == {"PROJECT_NO_TESTS", "PROJECT_NO_CONFIG"}


def test_size_binary_and_count_limits(project):
    (project / "large.txt").write_text("x" * 100)
    (project / "binary.txt").write_bytes(b"\x00\xff")
    (project / "bad.txt").write_bytes(b"\xff")
    context = inspect_project(project, max_bytes=60)
    assert context.read_text("large.txt") is None
    assert context.read_text("binary.txt") is None
    assert context.read_text("bad.txt") is None
    assert context.read_text("../external.txt") is None
    assert context.inventory.warnings
    limited = inspect_project(project, max_files=1)
    assert len(limited.inventory.files) == 1
    assert any("File limit" in w for w in limited.inventory.warnings)


def test_malformed_pyproject_does_not_crash(tmp_path):
    (tmp_path / "pyproject.toml").write_text("[invalid")
    assert "invalid TOML" in inspect_project(tmp_path).inventory.warnings[0]
    (tmp_path / "pyproject.toml").write_text('build-system = "wrong type"\ntool = 5')
    assert not inspect_project(tmp_path).inventory.is_python


def test_symlink_is_not_followed(tmp_path):
    external = tmp_path / "outside"
    external.mkdir()
    (external / "secret.py").write_text("pass")
    root = tmp_path / "repo"
    root.mkdir()
    try:
        (root / "linked").symlink_to(external, target_is_directory=True)
        (root / "linked.py").symlink_to(external / "secret.py")
    except OSError:
        pytest.skip("Creating symlinks requires Windows developer mode or elevated permission")
    assert not inspect_project(root).inventory.files


@pytest.mark.skipif(shutil.which("git") is None, reason="Git is optional")
def test_git_ignored_and_tracked_files(tmp_path):
    subprocess.run(["git", "init", str(tmp_path)], check=True, capture_output=True)
    (tmp_path / ".gitignore").write_text("ignored.py\n.env\n")
    (tmp_path / "ignored.py").write_text("pass")
    (tmp_path / ".env").write_text("SAMPLE=1")
    (tmp_path / "tracked.py").write_text("pass")
    subprocess.run(["git", "-C", str(tmp_path), "add", "tracked.py"], check=True)
    subprocess.run(["git", "-C", str(tmp_path), "add", "-f", ".env"], check=True)
    context = inspect_project(tmp_path)
    assert context.inventory.git_available
    assert "ignored.py" not in context.inventory.files
    assert set(context.inventory.tracked_files) == {".env", "tracked.py"}
    # Git emits paths relative to a nested scan target, too.
    child = tmp_path / "child"
    child.mkdir()
    (child / "nested.py").write_text("pass")
    assert inspect_project(child).inventory.files == ["nested.py"]


def test_read_refuses_new_symlink(project, monkeypatch):
    context = inspect_project(project)
    original = Path.is_symlink
    monkeypatch.setattr(Path, "is_symlink", lambda p: p.name == "app.py" or original(p))
    assert context.read_text("app.py") is None
