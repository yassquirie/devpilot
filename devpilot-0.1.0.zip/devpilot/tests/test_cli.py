"""End-to-end command parsing, real Ruff, exports, redaction, and exit codes."""

import json
import os
import subprocess
import sys

import pytest
from typer.testing import CliRunner

from devpilot.cli.app import app

runner = CliRunner()


@pytest.mark.parametrize("command", ["scan", "quality", "security", "report"])
def test_commands_and_json(project, command):
    result = runner.invoke(app, [command, str(project), "--format", "json"])
    assert result.exit_code == 0, result.output
    data = json.loads(result.stdout)
    assert data["inventory"]["is_python"]
    assert data["score"]["value"] == 100


def test_help_version_and_invalid_path(tmp_path):
    assert runner.invoke(app, ["--help"]).exit_code == 0
    assert "DevPilot 0.1.0" in runner.invoke(app, ["--version"]).output
    result = runner.invoke(app, ["scan", str(tmp_path / "absent")])
    assert result.exit_code == 2
    assert "Error:" in result.output
    assert "Traceback" not in result.output


def test_export_and_no_overwrite(project, tmp_path):
    output = tmp_path / "report.md"
    result = runner.invoke(app, ["report", str(project), "--output", str(output)])
    assert result.exit_code == 0, result.output
    assert output.read_text(encoding="utf-8").startswith("# DevPilot report:")
    original = output.read_bytes()
    assert runner.invoke(app, ["report", str(project), "-o", str(output)]).exit_code == 2
    assert output.read_bytes() == original
    assert runner.invoke(app, ["scan", str(project), "-o", str(tmp_path / "new")]).exit_code == 2


@pytest.mark.parametrize("format", ["terminal", "json", "markdown"])
def test_secret_redacted_in_all_formats(project, format):
    credential = "Sensitive" + "Credential987654321"
    (project / "settings.py").write_text(f'API_KEY = "{credential}"\n')
    result = runner.invoke(app, ["scan", str(project), "-f", format])
    assert result.exit_code == 0
    assert credential not in result.output
    assert "REDACTED" in result.output


def test_threshold_and_incomplete_exit_codes(project):
    (project / "settings.py").write_text("DEBUG = True\n")
    args = ["security", str(project)]
    assert runner.invoke(app, args).exit_code == 0
    assert runner.invoke(app, [*args, "--fail-on", "medium"]).exit_code == 1
    assert runner.invoke(app, [*args, "--fail-on", "high"]).exit_code == 0
    result = runner.invoke(app, ["scan", str(project), "-f", "json", "--max-files", "1"])
    assert result.exit_code == 3
    assert json.loads(result.stdout)["score"]["provisional"]


def test_write_error_and_unknown_format(project, tmp_path):
    args = ["report", str(project)]
    result = runner.invoke(app, [*args, "-o", str(tmp_path / "missing" / "out.md")])
    assert result.exit_code == 2
    assert "Cannot create report" in result.output
    assert runner.invoke(app, [*args, "-f", "xml"]).exit_code == 2


def test_exclusion_and_positive_limits(project):
    result = runner.invoke(app, ["scan", str(project), "--exclude", "tests", "-f", "json"])
    assert result.exit_code == 0
    assert "tests/test_app.py" not in json.loads(result.stdout)["inventory"]["files"]
    assert runner.invoke(app, ["scan", str(project), "--max-files", "0"]).exit_code == 2


def test_redirected_json_is_utf8_under_legacy_encoding(project):
    (project / "caf\u00e9_\u03bb.py").write_text("VALUE = 1\n", encoding="utf-8")
    result = subprocess.run(
        [sys.executable, "-m", "devpilot", "security", str(project), "--format", "json"],
        env={**os.environ, "PYTHONIOENCODING": "ascii"},
        capture_output=True,
        timeout=30,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert "caf\u00e9_\u03bb.py" in json.loads(result.stdout.decode("utf-8"))["inventory"]["files"]
