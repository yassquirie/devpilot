"""Exercise real Ruff plus controlled timeout and malformed-output failures."""

import subprocess
from types import SimpleNamespace

import pytest

from devpilot.quality.ruff import analyze_quality
from devpilot.scanner.project import inspect_project


def test_real_ruff_unused_import_and_no_modification(project):
    source = "import os\n\nprint(missing_name)\n"
    (project / "app.py").write_text(source)
    result = analyze_quality(inspect_project(project))
    assert result.status == "complete"
    assert {f.rule for f in result.findings} >= {"RUFF_F401", "RUFF_F821"}
    assert all(f.line for f in result.findings)
    assert (project / "app.py").read_text() == source
    assert not (project / ".ruff_cache").exists()


def test_no_python_files_skips(tmp_path):
    assert analyze_quality(inspect_project(tmp_path)).status == "skipped"


@pytest.mark.parametrize("kind", ["missing", "timeout", "json", "exit", "shape"])
def test_ruff_failure_is_partial(project, monkeypatch, kind):
    context = inspect_project(project)

    def fake(*args, **kwargs):
        if kind == "missing":
            raise OSError("missing")
        if kind == "timeout":
            raise subprocess.TimeoutExpired("ruff", 1)
        if kind == "json":
            return SimpleNamespace(returncode=0, stdout="invalid", stderr="")
        if kind == "shape":
            return SimpleNamespace(returncode=0, stdout='{"error": "x"}', stderr="")
        return SimpleNamespace(returncode=2, stdout="", stderr="sensitive source")

    monkeypatch.setattr("devpilot.quality.ruff.subprocess.run", fake)
    result = analyze_quality(context)
    assert result.status == "partial"
    assert "sensitive source" not in result.model_dump_json()


def test_ruff_timeout_budget(project):
    assert analyze_quality(inspect_project(project), timeout=0).status == "partial"
