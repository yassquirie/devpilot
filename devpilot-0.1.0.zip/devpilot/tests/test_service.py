"""Orchestration preserves coverage and opt-in networking semantics."""

import pytest
from typer.testing import CliRunner

from devpilot.cli.app import app
from devpilot.models import CheckResult
from devpilot.service import build_report


def test_update_flag_reaches_analyzer_without_network(project, monkeypatch):
    calls = []

    def fake(context, *, online):
        calls.append(online)
        return CheckResult(category="security", status="partial", notes=["Simulated outage."])

    monkeypatch.setattr("devpilot.service.check_dependencies", fake)
    result = CliRunner().invoke(app, ["security", str(project), "--check-updates", "-f", "json"])
    assert calls == [True]
    assert result.exit_code == 3
    assert "Simulated outage" in result.stdout


def test_read_failure_does_not_claim_complete_quality(project):
    (project / "app.py").write_bytes(b"\xff")
    report = build_report(project)
    quality = next(c for c in report.checks if c.category == "quality")
    assert quality.status == "partial"
    assert report.score.provisional
    assert report.inventory.warnings


def test_invalid_mode(project):
    with pytest.raises(ValueError, match="Unsupported"):
        build_report(project, mode="unknown")
