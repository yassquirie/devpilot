"""All dependency tests use fake metadata; tests never contact PyPI."""

import io
import json

import pytest
from packaging.version import Version

from devpilot.scanner.project import inspect_project
from devpilot.security.dependencies import (
    DependencyLookupError,
    check_dependencies,
    latest_release,
)


def test_offline_never_calls_network(project):
    def forbidden(_):
        pytest.fail("offline check attempted network")

    result = check_dependencies(inspect_project(project), online=False, lookup=forbidden)
    assert not result.findings
    assert "offline" in result.notes[0]


def test_exact_pins_ranges_markers_and_urls(project):
    (project / "requirements.txt").write_text(
        "requests==2.0.0\nrequests==2.0.0 # duplicate\n"
        "other>=1\nconditional==1.0; sys_platform=='linux'\n"
        "private @ https://user:password@example.invalid/file.whl\n-r private.txt\n"
    )
    calls = []

    def lookup(name):
        calls.append(name)
        return Version("3.0.0")

    result = check_dependencies(inspect_project(project), online=True, lookup=lookup)
    assert calls == ["requests"]
    assert len(result.findings) == 2
    assert result.status == "partial"
    assert "password" not in result.model_dump_json()


def test_pep440_current_pin_and_outage(project):
    (project / "requirements.txt").write_text("package==10.0\n")
    result = check_dependencies(
        inspect_project(project), online=True, lookup=lambda _: Version("2.0")
    )
    assert not result.findings

    def unavailable(_):
        raise DependencyLookupError("unavailable")

    result = check_dependencies(inspect_project(project), online=True, lookup=unavailable)
    assert result.status == "partial"
    assert not result.findings


def test_project_dependencies_and_invalid_schema(project):
    with (project / "pyproject.toml").open("a") as handle:
        handle.write('dependencies = ["sample==1.0"]\n')
    result = check_dependencies(
        inspect_project(project), online=True, lookup=lambda _: Version("2.0")
    )
    assert result.findings[0].path == "pyproject.toml"
    context = inspect_project(project)
    context.pyproject = {"project": {"dependencies": 42}}
    assert check_dependencies(context, online=True).status == "partial"


def test_lookup_limit(project):
    (project / "requirements.txt").write_text("\n".join(f"pkg{i}==1.0" for i in range(23)))
    calls = []

    def lookup(name):
        calls.append(name)
        return Version("1.0")

    result = check_dependencies(inspect_project(project), online=True, lookup=lookup)
    assert len(calls) == 20
    assert result.status == "partial"


@pytest.mark.parametrize(
    "payload, valid",
    [
        ({"info": {"version": "2.0"}, "urls": [{"yanked": False}]}, True),
        ({"info": {"version": "2.0rc1"}, "urls": [{"yanked": False}]}, False),
        ({"info": {"version": "2.0"}, "urls": [{"yanked": True}]}, False),
        ({"info": {"version": "not-a-version"}}, False),
        ([], False),
        ({"info": []}, False),
    ],
)
def test_pypi_metadata_validation(monkeypatch, payload, valid):
    monkeypatch.setattr(
        "devpilot.security.dependencies.urlopen",
        lambda *a, **k: io.BytesIO(json.dumps(payload).encode()),
    )
    if valid:
        assert latest_release("sample") == Version("2.0")
    else:
        with pytest.raises(DependencyLookupError):
            latest_release("sample")


def test_invalid_package_name():
    with pytest.raises(DependencyLookupError):
        latest_release("../../bad")
