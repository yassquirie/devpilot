# Security scope and reporting

## What DevPilot can flag

DevPilot looks for a small set of recognizable token shapes, private-key headers,
and literal assignments to sensitive names such as API_KEY, PASSWORD, and
ACCESS_TOKEN. It skips obvious placeholders and environment-variable references.
It also flags tracked `.env` files, literal debug mode, disabled TLS verification,
and one common wildcard allowed-hosts pattern. These are review prompts.

Reports use a fixed redaction marker and locations. They never intentionally store
or print detected secret values, secret previews, source snippets, raw Ruff
diagnostics, raw requirement declarations, HTTP response text, or subprocess stderr.
Review the file locally to determine whether a finding is real. If a credential
was exposed, revoke or rotate it; deleting a line alone does not remove exposure.

## What DevPilot cannot establish

- It does not validate credentials or prove that any string is a live secret.
- It scans selected working-tree files, not Git history, branches, remote hosts,
  archives, binary data, runtime memory, or every possible text encoding/extension.
- Git tracking means present in the index, not proof a value reached a commit or
  remote. Ignored untracked files are outside Git-aware scope.
- It can miss encoded, split, obfuscated, encrypted, multiline, provider-specific,
  or unusually named secrets. It is not an entropy-based or comprehensive detector.
- Comments, tests, sample code, local debug settings, public identifiers, and
  sensitive variable references can create false positives. Placeholder filtering
  can also hide a real credential that resembles a sample.
- It does not model deployment context, data flow, authorization, injection,
  network exposure, container hardening, or infrastructure security.
- It does not audit dependency vulnerabilities or transitive dependencies. A newer
  version on PyPI does not establish an exploitable flaw in the pinned version.
- File size/count/read limits, exclusions, unsupported declarations, and timeouts
  can reduce coverage. Inspect statuses and warnings, not only the score.

Filenames, project names, and normalized dependency names appear in reports.
Do not put credentials in filenames or package names. Treat reports as potentially
sensitive metadata, especially before sharing them publicly. JSON escapes control
characters; Markdown and terminal renderers sanitize control characters and escape
untrusted markup. This does not make arbitrary report content safe in every host
application.

DevPilot does not execute scanned code, tests, setup files, hooks, or repository
Ruff configuration. It invokes installed Git and Ruff and optionally public PyPI.
It is not a sandbox: run it with ordinary user privileges on a stable working tree.
Concurrent file changes and hostile filesystem races are outside its guarantees.
Optional online checks disclose queried package names to PyPI and use the normal
system network/proxy environment.

## Reporting a vulnerability in DevPilot

Before public hosting, maintainers must configure a private security contact or
GitHub private vulnerability reporting. Once enabled, use that channel rather than
a public issue. If no private channel is available, open an issue requesting a
private contact without exploit details, repository contents, or credentials.
Use synthetic reproductions and redacted reports. This project currently makes no
response-time or supported-version security commitment.
