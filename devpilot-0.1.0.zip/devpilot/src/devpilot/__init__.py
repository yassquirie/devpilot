"""DevPilot: transparent, read-only project health checks."""

__version__ = "0.1.0"
