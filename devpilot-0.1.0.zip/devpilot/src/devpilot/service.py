"""Orchestrate analyzers independently of the command-line interface."""

from pathlib import Path
from typing import Literal

from devpilot import __version__
from devpilot.documentation.analyzer import analyze_documentation
from devpilot.models import Report
from devpilot.quality.ruff import analyze_quality
from devpilot.reporting.score import calculate_score
from devpilot.scanner.project import analyze_structure, inspect_project
from devpilot.security.dependencies import check_dependencies
from devpilot.security.secrets import analyze_security


def build_report(
    target: Path,
    *,
    mode: Literal["scan", "quality", "security", "report"] = "scan",
    online: bool = False,
    excludes: tuple[str, ...] = (),
    max_bytes: int = 1_048_576,
    max_files: int = 20_000,
) -> Report:
    """Run requested checks, preserving incomplete coverage instead of claiming success."""
    if mode not in {"scan", "quality", "security", "report"}:
        raise ValueError("Unsupported report mode")
    context = inspect_project(target, excludes=excludes, max_bytes=max_bytes, max_files=max_files)
    checks = []
    if mode in {"scan", "report"}:
        checks.extend([analyze_structure(context), analyze_documentation(context)])
    if mode in {"scan", "report", "quality"}:
        checks.append(analyze_quality(context))
    if mode in {"scan", "report", "security"}:
        security = analyze_security(context)
        dependencies = check_dependencies(context, online=online)
        security.findings.extend(dependencies.findings)
        security.notes.extend(dependencies.notes)
        if dependencies.status == "partial":
            security.status = "partial"
        checks.append(security)
    if context.read_problems:
        context.inventory.warnings.append(
            f"{len(context.read_problems)} file(s) were unreadable, binary, oversized, "
            "or changed during scanning."
        )
    if context.inventory.warnings or context.inventory.skipped_files:
        for check in checks:
            if check.status == "complete":
                check.status = "partial"
                check.notes.append(
                    "Coverage was limited; see inventory warnings and content skips."
                )
    return Report(
        tool_version=__version__,
        inventory=context.inventory,
        checks=checks,
        score=calculate_score(checks),
    )
