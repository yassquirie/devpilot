"""Render the same report model to Markdown, JSON, or a Rich terminal."""

import re

from rich.console import Console
from rich.table import Table
from rich.text import Text

from devpilot.models import Report


def safe_text(text: str) -> str:
    """Escape controls and terminal escape bytes from repository-controlled names."""
    return re.sub(r"[\x00-\x1f\x7f-\x9f]", lambda m: f"\\x{ord(m[0]):02x}", text)


def _md(text: str) -> str:
    return re.sub(r"([\\`*_{}\[\]<>()|#!])", r"\\\1", safe_text(text))


def render_markdown(report: Report) -> str:
    """Produce a portable Markdown report with coverage and scoring details."""
    inv = report.inventory
    score = report.score
    lines = [
        f"# DevPilot report: {_md(inv.project_name)}",
        "",
        f"Generated: {report.generated_at.isoformat()} · DevPilot {report.tool_version}",
        "",
        f"**Health score: {score.value if score.value is not None else 'N/A'}/100**"
        + (" (provisional)" if score.provisional else ""),
        "",
        f"Python project: {inv.is_python} · Files: {len(inv.files)} · "
        f"Python source files: {inv.source_files} · Content skips: {inv.skipped_files}",
        "",
        "## Project structure",
        "",
        "| Root entry | Files |",
        "| --- | ---: |",
    ]
    lines.extend(f"| {_md(k)} | {v} |" for k, v in inv.top_level.items())
    lines.extend(
        ["", "Configuration files: " + (", ".join(_md(x) for x in inv.config_files) or "none"), ""]
    )
    if inv.warnings:
        lines.extend(["## Coverage warnings", ""])
        lines.extend(f"- {_md(w)}" for w in inv.warnings)
        lines.append("")
    for check in report.checks:
        lines.extend([f"## {check.category.title()} ({check.status})", ""])
        lines.extend(f"- {_md(note)}" for note in check.notes)
        if check.notes:
            lines.append("")
        for finding in check.findings:
            location = finding.path or "project"
            if finding.line:
                location += f":{finding.line}"
            lines.extend(
                [
                    f"- **{finding.severity.upper()} · {_md(finding.rule)}** — {_md(location)}",
                    f"  {_md(finding.message)} {_md(finding.suggestion)}",
                ]
            )
        if not check.findings:
            lines.append(
                "No findings in the evaluated scope."
                if check.status != "skipped"
                else "Check was not run."
            )
        lines.append("")
    lines.extend(
        [
            "## Scoring",
            "",
            "| Category | Earned | Available | Deducted |",
            "| --- | ---: | ---: | ---: |",
        ]
    )
    lines.extend(
        f"| {p.category} | {p.earned} | {p.available} | {p.deducted} |" for p in score.parts
    )
    lines.extend(["", score.methodology, ""])
    return "\n".join(lines)


def render_terminal(report: Report, console: Console) -> None:
    """Print findings without interpreting Rich markup from repository names."""
    inv = report.inventory
    label = str(report.score.value) if report.score.value is not None else "N/A"
    console.print(f"DevPilot · {safe_text(inv.project_name)}", style="bold", markup=False)
    console.print(f"Health: {label}/100" + (" (provisional)" if report.score.provisional else ""))
    console.print(f"Python: {inv.is_python} | Files: {len(inv.files)} | Source: {inv.source_files}")
    console.print(
        "Structure: " + ", ".join(f"{safe_text(k)} ({v})" for k, v in inv.top_level.items()),
        markup=False,
    )
    console.print(
        "Configuration: " + (", ".join(safe_text(x) for x in inv.config_files) or "none"),
        markup=False,
    )
    for warning in inv.warnings:
        console.print(f"Coverage: {safe_text(warning)}", style="yellow", markup=False)
    for check in report.checks:
        console.print(f"\n{check.category.title()} · {check.status}", style="bold")
        for note in check.notes:
            console.print(safe_text(note), style="dim", markup=False)
        table = Table("Severity", "Rule / location", "Finding and action", expand=True)
        for finding in check.findings:
            location = finding.path or "project"
            if finding.line:
                location += f":{finding.line}"
            table.add_row(
                Text(finding.severity.upper()),
                Text(f"{finding.rule}\n{safe_text(location)}"),
                Text(f"{finding.message}\n{finding.suggestion}"),
            )
        if check.findings:
            console.print(table)
        else:
            console.print(
                "No findings in the evaluated scope."
                if check.status != "skipped"
                else "Check was not run."
            )
    console.print("\nScore breakdown", style="bold")
    for part in report.score.parts:
        console.print(f"{part.category}: {part.earned}/{part.available} (-{part.deducted})")
    console.print(report.score.methodology, style="dim")


def serialize(report: Report, format: str) -> str:
    """Serialize a report, rejecting unknown formats at the API boundary."""
    if format == "json":
        return report.model_dump_json(indent=2) + "\n"
    if format == "markdown":
        return render_markdown(report)
    raise ValueError("Expected json or markdown format")
