"""Score calculation and report serialization."""
