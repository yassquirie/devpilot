"""Small, inspectable heuristic scoring policy."""

from devpilot.models import CheckResult, HealthScore, ScorePart

BUDGETS = {"scanner": 10, "quality": 30, "security": 40, "documentation": 20}
PENALTIES = {"high": 15, "medium": 5, "low": 2, "info": 0}
METHODOLOGY = (
    "Budgets: scanner 10, quality 30, security 40, documentation 20. "
    "Each finding deducts high=15, medium=5, low=2, info=0 points from its category, "
    "capped at that category's budget. Score = floor(100 * earned / available). "
    "Skipped categories are excluded. Partial checks retain their budget and make the score "
    "provisional; missing coverage never proves health. "
    "Scores on different scopes are not comparable. "
    "Offline dependency freshness is outside the default score's scope. "
    "This is not a security rating."
)


def calculate_score(checks: list[CheckResult]) -> HealthScore:
    """Calculate a reproducible score with per-category point deductions."""
    parts = []
    for check in checks:
        if check.status == "skipped":
            continue
        available = BUDGETS[check.category]
        deduction = min(available, sum(PENALTIES[f.severity] for f in check.findings))
        parts.append(
            ScorePart(
                category=check.category,
                available=available,
                deducted=deduction,
                earned=available - deduction,
            )
        )
    total = sum(p.available for p in parts)
    return HealthScore(
        value=100 * sum(p.earned for p in parts) // total if total else None,
        provisional=any(c.status != "complete" for c in checks),
        parts=parts,
        methodology=METHODOLOGY,
    )
