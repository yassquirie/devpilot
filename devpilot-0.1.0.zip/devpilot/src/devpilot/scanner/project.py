"""Discover files without executing project code or following symbolic links."""

import fnmatch
import os
import shutil
import stat
import subprocess
import tomllib
from collections import Counter
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

from devpilot.models import CheckResult, Finding, Inventory

DEFAULT_EXCLUDES = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        ".venv",
        "venv",
        "env",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        ".ruff_cache",
        ".mypy_cache",
        ".tox",
        ".nox",
        "dist",
        "build",
        "site-packages",
        ".eggs",
        "htmlcov",
    }
)
CONFIG_NAMES = frozenset(
    {
        "pyproject.toml",
        "setup.py",
        "setup.cfg",
        "requirements.txt",
        "Pipfile",
        "Pipfile.lock",
        "poetry.lock",
        "uv.lock",
        "tox.ini",
        "pytest.ini",
        ".pre-commit-config.yaml",
        ".gitignore",
        "ruff.toml",
        ".ruff.toml",
        "Dockerfile",
        "docker-compose.yml",
    }
)


class ScanError(ValueError):
    """An invalid or inaccessible scan target."""


@dataclass
class ScanContext:
    """Internal scan state; raw file content is never attached to a report."""

    root: Path
    inventory: Inventory
    max_bytes: int
    read_problems: set[str] = field(default_factory=set)
    pyproject: dict = field(default_factory=dict)

    def read_text(self, relative: str) -> str | None:
        """Read bounded UTF-8 text; refuse links, binaries and external paths."""
        path = self.root / relative
        try:
            if any(p.is_symlink() for p in [path, *path.parents] if p != self.root):
                self.read_problems.add(relative)
                return None
            path.resolve().relative_to(self.root)
            if not stat.S_ISREG(path.stat().st_mode):
                self.read_problems.add(relative)
                return None
            with path.open("rb") as handle:
                content = handle.read(self.max_bytes + 1)
            if len(content) > self.max_bytes or b"\x00" in content:
                self.read_problems.add(relative)
                return None
            return content.decode("utf-8-sig")
        except (OSError, ValueError, UnicodeError):
            self.read_problems.add(relative)
            return None


def _git_files(root: Path) -> tuple[set[str], set[str]] | None:
    """Use Git's ignore rules when Git is available; never inspect history."""
    try:
        executable = shutil.which("git")
        if executable is None:
            return None
        executable_path = Path(executable).resolve()
        if executable_path.is_relative_to(root):
            # Windows may search the current project before PATH for executables.
            return None
        lists = []
        for options in [("--cached", "--others", "--exclude-standard"), ("--cached",)]:
            proc = subprocess.run(
                [
                    str(executable_path),
                    "-c",
                    "core.fsmonitor=false",
                    "-C",
                    str(root),
                    "ls-files",
                    "-z",
                    *options,
                    "--",
                    ".",
                ],
                capture_output=True,
                timeout=10,
                check=False,
            )
            if proc.returncode != 0:
                return None
            lists.append(set(proc.stdout.decode("utf-8").rstrip("\0").split("\0")) - {""})
        return lists[0], lists[1]
    except (OSError, UnicodeError, subprocess.TimeoutExpired):
        return None


def _excluded(relative: str, patterns: tuple[str, ...]) -> bool:
    parts = Path(relative).parts
    return any(p in DEFAULT_EXCLUDES or p.endswith(".egg-info") for p in parts) or any(
        fnmatch.fnmatchcase(relative, p) or any(fnmatch.fnmatchcase(x, p) for x in parts)
        for p in patterns
    )


def inspect_project(
    target: Path,
    *,
    excludes: tuple[str, ...] = (),
    max_bytes: int = 1_048_576,
    max_files: int = 20_000,
) -> ScanContext:
    """Inventory a local directory with explicit size and file-count limits."""
    if max_bytes < 1 or max_files < 1:
        raise ScanError("Scan limits must be positive.")
    try:
        root = target.expanduser().resolve(strict=True)
        if not root.is_dir():
            raise ScanError("The scan target must be a directory.")
        with os.scandir(root):
            pass
    except (OSError, RuntimeError) as exc:
        raise ScanError("The scan target does not exist or cannot be read.") from exc

    git = _git_files(root)
    warnings: list[str] = []
    files: list[str] = []
    skipped = 0

    def on_error(_: OSError) -> None:
        warnings.append("A directory could not be read; inventory is incomplete.")

    if git is not None:
        candidates = iter(sorted(git[0]))
    else:

        def walk() -> Iterator[str]:
            for base, dirs, names in os.walk(root, followlinks=False, onerror=on_error):
                dirs[:] = sorted(
                    d
                    for d in dirs
                    if not (Path(base) / d).is_symlink()
                    and not _excluded((Path(base) / d).relative_to(root).as_posix(), excludes)
                )
                for name in sorted(names):
                    yield (Path(base) / name).relative_to(root).as_posix()

        candidates = walk()

    for relative in candidates:
        if _excluded(relative, excludes):
            continue
        if len(files) >= max_files:
            warnings.append(f"File limit ({max_files}) reached; inventory is incomplete.")
            break
        path = root / relative
        try:
            path.resolve().relative_to(root)
            if path.is_symlink() or any(p.is_symlink() for p in path.parents if p != root):
                skipped += 1
                continue
            if not path.exists():  # Deleted tracked file; not part of the working tree.
                continue
            info = path.stat()
            if not stat.S_ISREG(info.st_mode):
                skipped += 1
                continue
            files.append(relative)
            if info.st_size > max_bytes:
                skipped += 1
                warnings.append(f"Content exceeds byte limit: {relative}")
        except (OSError, ValueError):
            skipped += 1
            warnings.append("A file could not be inspected; inventory is incomplete.")

    source_count = sum(Path(f).suffix.lower() in {".py", ".pyi"} for f in files)
    markers = {"setup.py", "setup.cfg", "requirements.txt", "Pipfile", "poetry.lock", "uv.lock"}
    inventory = Inventory(
        project_name=root.name,
        is_python=bool(source_count or markers.intersection(files)),
        files=sorted(files),
        source_files=source_count,
        top_level=dict(sorted(Counter(f.split("/")[0] for f in files).items())),
        config_files=sorted(
            f
            for f in files
            if Path(f).name in CONFIG_NAMES
            or Path(f).name.startswith("requirements")
            and f.endswith(".txt")
        ),
        git_available=git is not None,
        tracked_files=sorted(set(files).intersection(git[1])) if git else [],
        skipped_files=skipped,
        warnings=list(dict.fromkeys(warnings)),
    )
    context = ScanContext(root=root, inventory=inventory, max_bytes=max_bytes)
    if "pyproject.toml" in files:
        text = context.read_text("pyproject.toml")
        if text is not None:
            try:
                context.pyproject = tomllib.loads(text)
                data = context.pyproject
                build_system = data.get("build-system", {})
                tool = data.get("tool", {})
                build = (
                    build_system.get("build-backend", "") if isinstance(build_system, dict) else ""
                )
                inventory.is_python |= bool(
                    "project" in data or isinstance(tool, dict) and "poetry" in tool or build
                )
            except tomllib.TOMLDecodeError:
                inventory.warnings.append("pyproject.toml is invalid TOML; metadata was not read.")
    return context


def analyze_structure(context: ScanContext) -> CheckResult:
    """Identify baseline project structure gaps."""
    result = CheckResult(category="scanner")
    if not context.inventory.is_python:
        result.findings.append(
            Finding(
                rule="PROJECT_NOT_PYTHON",
                severity="info",
                message="No Python project markers found.",
                suggestion="Use a Python repository; generic documentation checks still run.",
            )
        )
    elif not any(
        f == "tests.py" or f.startswith("tests/") or Path(f).name.startswith("test_")
        for f in context.inventory.files
        if f.endswith(".py")
    ):
        result.findings.append(
            Finding(
                rule="PROJECT_NO_TESTS",
                severity="medium",
                message="No conventional Python tests found.",
                suggestion="Add tests/ with pytest tests for the project's public behavior.",
            )
        )
    if (
        context.inventory.is_python
        and not any(
            f in context.inventory.files
            for f in ("pyproject.toml", "setup.py", "setup.cfg", "Pipfile")
        )
        and not any(Path(f).name.startswith("requirements") for f in context.inventory.config_files)
    ):
        result.findings.append(
            Finding(
                rule="PROJECT_NO_CONFIG",
                severity="low",
                message="No Python dependency configuration found.",
                suggestion="Declare project metadata and dependencies in pyproject.toml.",
            )
        )
    return result
