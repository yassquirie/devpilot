"""Repository inventory and bounded text access."""
