"""Check documentation presence and simple installation signals."""

import re
from pathlib import PurePosixPath

from devpilot.models import CheckResult, Finding
from devpilot.scanner.project import ScanContext


def analyze_documentation(context: ScanContext) -> CheckResult:
    """Check conventional README, license, and contributor documentation locations."""
    result = CheckResult(category="documentation")
    lower = {f.lower(): f for f in context.inventory.files}
    readme = lower.get("readme.md")
    if readme is None:
        result.findings.append(
            Finding(
                rule="DOC_README",
                severity="medium",
                message="README.md is missing at the project root.",
                suggestion="Add README.md with purpose, installation, and a minimal usage example.",
            )
        )
    else:
        content = context.read_text(readme)
        if content is None:
            result.status = "partial"
            result.notes.append("README content could not be checked.")
        elif not re.search(
            r"(?im)^#{1,6}\s+.*(?:install|getting started|quick\s*start|setup)"
            r"|\b(?:pip|uv|poetry)\s+(?:install|sync|add)\b",
            content,
        ):
            result.findings.append(
                Finding(
                    rule="DOC_INSTALL",
                    severity="low",
                    path=readme,
                    message="README has no recognized installation instructions.",
                    suggestion="Add an Installation heading with reproducible setup commands.",
                )
            )
    root_names = {PurePosixPath(f).name.lower() for f in lower if "/" not in f}
    if not any(
        name in {"license", "licence", "copying"}
        or name.startswith(("license.", "licence.", "copying."))
        for name in root_names
    ):
        result.findings.append(
            Finding(
                rule="DOC_LICENSE",
                severity="medium",
                message="No root license file found.",
                suggestion="Choose an appropriate license and add LICENSE.",
            )
        )
    if not any(
        f in lower for f in ("contributing.md", ".github/contributing.md", "docs/contributing.md")
    ):
        result.findings.append(
            Finding(
                rule="DOC_CONTRIBUTING",
                severity="low",
                message="Contribution guidelines are missing.",
                suggestion="Add CONTRIBUTING.md with setup, test, lint, and review instructions.",
            )
        )
    return result
