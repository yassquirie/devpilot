"""Ruff-backed quality analysis."""
