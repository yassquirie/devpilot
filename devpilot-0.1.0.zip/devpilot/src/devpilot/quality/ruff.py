"""Run Ruff on bounded stdin, keeping source and diagnostics out of reports."""

import json
import subprocess
import sys
import time
from pathlib import Path

from devpilot.models import CheckResult, Finding
from devpilot.scanner.project import ScanContext

SUGGESTIONS = {
    "F401": "Remove the unused import or explicitly re-export the public symbol.",
    "F821": "Define the name or correct the reference before running this code.",
    "F841": "Remove the unused assignment or use its value.",
    "E722": "Catch a specific exception instead of using a bare except clause.",
    "E711": "Use 'is None' or 'is not None' when comparing with None.",
    "E712": "Use a direct truth test instead of comparing with True or False.",
}


def analyze_quality(context: ScanContext, *, timeout: float = 30) -> CheckResult:
    """Apply fixed E/F rules; honor noqa, ignore repository Ruff configuration."""
    result = CheckResult(category="quality")
    files = [f for f in context.inventory.files if Path(f).suffix.lower() in {".py", ".pyi"}]
    if not files:
        result.status = "skipped"
        result.notes.append("No Python source files in scope.")
        return result
    result.notes.append(
        "Ruff E/F rules; isolated configuration, no fixes, source snippets omitted."
    )
    deadline = time.monotonic() + timeout
    for relative in files:
        text = context.read_text(relative)
        if text is None:
            result.status = "partial"
            continue
        try:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise subprocess.TimeoutExpired("ruff", timeout)
            proc = subprocess.run(
                [
                    sys.executable,
                    "-I",
                    "-m",
                    "ruff",
                    "check",
                    "--isolated",
                    "--no-cache",
                    "--output-format",
                    "json",
                    "--select",
                    "E,F",
                    "--target-version",
                    "py311",
                    "--stdin-filename",
                    relative,
                    "-",
                ],
                input=text,
                encoding="utf-8",
                capture_output=True,
                timeout=remaining,
                check=False,
            )
            if proc.returncode not in (0, 1):
                result.status = "partial"
                result.notes.append(
                    "Ruff failed or is unavailable; reinstall DevPilot's dependencies."
                )
                break
            diagnostics = json.loads(proc.stdout)
            if not isinstance(diagnostics, list):
                raise ValueError("Invalid Ruff result")
            for item in diagnostics:
                if not isinstance(item, dict):
                    raise ValueError("Invalid Ruff diagnostic")
                code = item.get("code") or "invalid-syntax"
                # Do not copy Ruff messages: they can embed source literals and credentials.
                if not isinstance(code, str) or not code.replace("-", "").isalnum():
                    raise ValueError("Invalid Ruff rule")
                result.findings.append(
                    Finding(
                        rule=f"RUFF_{code}",
                        severity="medium" if code in {"F821", "invalid-syntax"} else "low",
                        path=relative,
                        line=item["location"]["row"],
                        message=f"Ruff detected {code}.",
                        suggestion=SUGGESTIONS.get(
                            code, "Review the indicated line and Ruff rule documentation."
                        ),
                    )
                )
        except (OSError, ValueError, KeyError, TypeError, subprocess.TimeoutExpired):
            result.status = "partial"
            result.notes.append(
                "Ruff could not finish within its budget or returned invalid output."
            )
            break
    if context.read_problems:
        result.notes.append("Some files could not be read as bounded UTF-8 text.")
    return result
