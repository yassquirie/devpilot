"""Support ``python -m devpilot``."""

from devpilot.cli.app import app

app()
