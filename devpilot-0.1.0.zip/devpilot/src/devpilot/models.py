"""Serializable contracts shared by analyzers and report renderers."""

from datetime import UTC, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Category = Literal["scanner", "quality", "security", "documentation"]
Severity = Literal["high", "medium", "low", "info"]
Status = Literal["complete", "partial", "skipped"]


class Model(BaseModel):
    """Reject unexpected fields at the report boundary."""

    model_config = ConfigDict(extra="forbid")


class Finding(Model):
    """An actionable observation; never store source snippets or secret values."""

    rule: str
    severity: Severity
    message: str
    suggestion: str
    path: str | None = None
    line: int | None = Field(default=None, ge=1)


class CheckResult(Model):
    """Findings and explicit coverage for one analyzer."""

    category: Category
    status: Status = "complete"
    findings: list[Finding] = Field(default_factory=list)
    notes: list[str] = Field(default_factory=list)


class Inventory(Model):
    """Inventory of in-scope files, using repository-relative POSIX paths."""

    project_name: str
    is_python: bool
    files: list[str]
    source_files: int
    top_level: dict[str, int]
    config_files: list[str]
    git_available: bool
    tracked_files: list[str]
    skipped_files: int = 0
    warnings: list[str] = Field(default_factory=list)


class ScorePart(Model):
    """Category points before normalization to a 100-point scale."""

    category: Category
    available: int
    deducted: int
    earned: int


class HealthScore(Model):
    """A heuristic maintenance score, never a security assurance."""

    value: int | None
    provisional: bool
    parts: list[ScorePart]
    methodology: str


class Report(Model):
    """Versioned report schema used by all output formats."""

    schema_version: str = "1.0"
    tool_version: str
    generated_at: datetime = Field(default_factory=lambda: datetime.now(UTC))
    inventory: Inventory
    checks: list[CheckResult]
    score: HealthScore
