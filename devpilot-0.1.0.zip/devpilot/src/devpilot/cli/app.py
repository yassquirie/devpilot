"""CLI commands, safe output handling, and predictable exit codes."""

from enum import StrEnum
from pathlib import Path
from typing import Annotated, Literal

import typer
from rich.console import Console

from devpilot import __version__
from devpilot.reporting.render import render_terminal, serialize
from devpilot.scanner.project import ScanError
from devpilot.service import build_report

app = typer.Typer(
    no_args_is_help=True,
    invoke_without_command=True,
    pretty_exceptions_enable=False,
    help="Read-only Python project health checks. Run 'devpilot scan .' to start.",
)


class OutputFormat(StrEnum):
    """Supported output formats."""

    terminal = "terminal"
    json = "json"
    markdown = "markdown"


class FailOn(StrEnum):
    """Optional minimum severity for findings to fail CI."""

    none = "none"
    high = "high"
    medium = "medium"
    low = "low"


PathArg = Annotated[
    Path, typer.Argument(help="Local project directory (default: current directory).")
]
FormatOpt = Annotated[OutputFormat, typer.Option("--format", "-f", help="Report output format.")]
OutputOpt = Annotated[
    Path | None, typer.Option("--output", "-o", help="Save JSON/Markdown; refuses existing files.")
]
ExcludeOpt = Annotated[
    list[str] | None,
    typer.Option("--exclude", help="Exclude a case-sensitive path/component glob; repeatable."),
]
OnlineOpt = Annotated[
    bool,
    typer.Option(
        "--check-updates", help="Send exact dependency package names to PyPI to check freshness."
    ),
]
FailOpt = Annotated[
    FailOn, typer.Option("--fail-on", help="Exit 1 for findings at this severity or above.")
]
BytesOpt = Annotated[
    int, typer.Option("--max-file-bytes", min=1, help="Maximum bytes read per file.")
]
FilesOpt = Annotated[
    int, typer.Option("--max-files", min=1, help="Maximum in-scope files inventoried.")
]


def _save_new(path: Path, content: str) -> None:
    """Create a report exclusively, cleaning up if writing fails."""
    destination = path.expanduser().absolute()
    created = False
    try:
        with destination.open(mode="x", encoding="utf-8", newline="\n") as handle:
            created = True
            handle.write(content)
    except OSError:
        if created:
            destination.unlink(missing_ok=True)
        raise


def _run(
    mode: Literal["scan", "quality", "security", "report"],
    path: Path,
    format: OutputFormat,
    output: Path | None,
    exclude: list[str] | None,
    check_updates: bool,
    fail_on: FailOn,
    max_file_bytes: int,
    max_files: int,
) -> None:
    """Build and emit a report, then apply the documented exit policy."""
    if output is not None and format == OutputFormat.terminal:
        raise typer.BadParameter("--output requires --format json or --format markdown.")
    if output is not None and (output.exists() or output.is_symlink()):
        raise typer.BadParameter("Output already exists; choose a new filename.")
    try:
        report = build_report(
            path,
            mode=mode,
            online=check_updates,
            excludes=tuple(exclude or []),
            max_bytes=max_file_bytes,
            max_files=max_files,
        )
    except ScanError as exc:
        typer.echo(f"Error: {exc}", err=True)
        raise typer.Exit(2) from None
    if format == OutputFormat.terminal:
        render_terminal(report, Console(highlight=False))
    else:
        content = serialize(report, format.value)
        if output is None:
            # Reports are UTF-8 even when a Windows pipe uses a legacy code page.
            typer.echo(content.encode("utf-8"), nl=False)
        else:
            try:
                _save_new(output, content)
            except OSError:
                typer.echo(
                    "Error: Cannot create report. Check the parent directory, permissions, "
                    "and whether the filename already exists.",
                    err=True,
                )
                raise typer.Exit(2) from None
            typer.echo("Report saved.", err=True)
    if any(check.status == "partial" for check in report.checks):
        raise typer.Exit(3)
    rank = {"high": 3, "medium": 2, "low": 1, "info": 0}
    if fail_on != FailOn.none and any(
        rank[f.severity] >= rank[fail_on.value] for c in report.checks for f in c.findings
    ):
        raise typer.Exit(1)


@app.callback()
def main(
    version: Annotated[
        bool, typer.Option("--version", is_eager=True, help="Show the installed DevPilot version.")
    ] = False,
) -> None:
    """Run a focused check or produce a complete project health report."""
    if version:
        typer.echo(f"DevPilot {__version__}")
        raise typer.Exit()


@app.command()
def scan(
    path: PathArg = Path("."),
    format: FormatOpt = OutputFormat.terminal,
    output: OutputOpt = None,
    exclude: ExcludeOpt = None,
    check_updates: OnlineOpt = False,
    fail_on: FailOpt = FailOn.none,
    max_file_bytes: BytesOpt = 1_048_576,
    max_files: FilesOpt = 20_000,
) -> None:
    """Inspect structure, documentation, Python quality, and security heuristics."""
    _run("scan", path, format, output, exclude, check_updates, fail_on, max_file_bytes, max_files)


@app.command()
def quality(
    path: PathArg = Path("."),
    format: FormatOpt = OutputFormat.terminal,
    output: OutputOpt = None,
    exclude: ExcludeOpt = None,
    fail_on: FailOpt = FailOn.none,
    max_file_bytes: BytesOpt = 1_048_576,
    max_files: FilesOpt = 20_000,
) -> None:
    """Find Python lint issues, including unused imports, using Ruff E/F rules."""
    _run("quality", path, format, output, exclude, False, fail_on, max_file_bytes, max_files)


@app.command()
def security(
    path: PathArg = Path("."),
    format: FormatOpt = OutputFormat.terminal,
    output: OutputOpt = None,
    exclude: ExcludeOpt = None,
    check_updates: OnlineOpt = False,
    fail_on: FailOpt = FailOn.none,
    max_file_bytes: BytesOpt = 1_048_576,
    max_files: FilesOpt = 20_000,
) -> None:
    """Check secret-like literals and risky settings; optionally verify dependency freshness."""
    _run(
        "security", path, format, output, exclude, check_updates, fail_on, max_file_bytes, max_files
    )


@app.command()
def report(
    path: PathArg = Path("."),
    format: FormatOpt = OutputFormat.markdown,
    output: OutputOpt = None,
    exclude: ExcludeOpt = None,
    check_updates: OnlineOpt = False,
    fail_on: FailOpt = FailOn.none,
    max_file_bytes: BytesOpt = 1_048_576,
    max_files: FilesOpt = 20_000,
) -> None:
    """Generate a complete report (Markdown by default), suitable for export."""
    _run("report", path, format, output, exclude, check_updates, fail_on, max_file_bytes, max_files)
