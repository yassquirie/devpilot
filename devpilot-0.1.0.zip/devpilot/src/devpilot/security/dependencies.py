"""Opt-in verification of exact direct dependency pins against PyPI metadata."""

import json
import re
from collections.abc import Callable
from urllib.error import URLError
from urllib.request import Request, urlopen

from packaging.requirements import InvalidRequirement, Requirement
from packaging.utils import canonicalize_name
from packaging.version import InvalidVersion, Version

from devpilot.models import CheckResult, Finding
from devpilot.scanner.project import ScanContext

MAX_PACKAGES = 20
MAX_RESPONSE = 2_097_152


class DependencyLookupError(ValueError):
    """A dependency's public release information could not be verified."""


def latest_release(name: str) -> Version:
    """Fetch public PyPI latest-release metadata with bounded reads and timeout."""
    if not re.fullmatch(r"[a-z0-9][a-z0-9._-]*", name):
        raise DependencyLookupError("Invalid package name")
    request = Request(
        f"https://pypi.org/pypi/{name}/json", headers={"User-Agent": "DevPilot/0.1.0"}
    )
    try:
        with urlopen(request, timeout=3) as response:  # noqa: S310
            payload = response.read(MAX_RESPONSE + 1)
        if len(payload) > MAX_RESPONSE:
            raise DependencyLookupError("Response too large")
        data = json.loads(payload)
        version = Version(data["info"]["version"])
        if version.is_prerelease or version.is_devrelease:
            raise DependencyLookupError("Latest release is not stable")
        if not any(not file.get("yanked", False) for file in data.get("urls", [])):
            raise DependencyLookupError("Latest release is yanked or has no files")
        return version
    except (
        TimeoutError,
        OSError,
        URLError,
        ValueError,
        KeyError,
        TypeError,
        AttributeError,
    ) as exc:
        # Never include a server response or raw requirement in a report or error.
        raise DependencyLookupError("Release metadata unavailable") from exc


def check_dependencies(
    context: ScanContext,
    *,
    online: bool,
    lookup: Callable[[str], Version] = latest_release,
) -> CheckResult:
    """Compare exact pins only; ranges, URLs and lock files are not resolved."""
    result = CheckResult(category="security")
    if not online:
        result.notes.append(
            "Dependency freshness not checked (offline); opt in with --check-updates."
        )
        return result
    result.notes.append(
        "Online freshness: exact direct pins in root requirements*.txt and [project].dependencies; "
        "at most 20 packages, 3s per request. Package names are sent to public PyPI. "
        "This is not a vulnerability or compatibility audit."
    )
    project = context.pyproject.get("project", {})
    raw: list[tuple[str, str, int | None]] = []
    dependencies = project.get("dependencies", []) if isinstance(project, dict) else []
    if not isinstance(dependencies, list):
        result.status = "partial"
        result.notes.append("Invalid project dependencies metadata; dependencies were not parsed.")
        dependencies = []
    for entry in dependencies:
        if isinstance(entry, str):
            raw.append((entry, "pyproject.toml", None))
        else:
            result.status = "partial"
    for path in context.inventory.files:
        if "/" in path or not re.fullmatch(r"requirements[^/]*\.txt", path):
            continue
        text = context.read_text(path)
        if text is None:
            result.status = "partial"
            continue
        for number, line in enumerate(text.splitlines(), 1):
            clean = re.split(r"\s+#", line, maxsplit=1)[0].strip()
            if clean and not clean.startswith("#"):
                raw.append((clean, path, number))
    checked: dict[str, Version | None] = {}
    skipped = 0
    pins = 0
    for text, path, line in raw:
        try:
            requirement = Requirement(text)
            specs = list(requirement.specifier)
            if requirement.url or len(specs) != 1 or specs[0].operator != "==":
                skipped += 1
                continue
            pin = Version(specs[0].version)
            if requirement.marker:
                # Environment markers depend on deployment context; do not guess it.
                skipped += 1
                continue
            name = str(canonicalize_name(requirement.name))
        except (InvalidRequirement, InvalidVersion):
            skipped += 1
            continue
        pins += 1
        if name not in checked:
            if len(checked) >= MAX_PACKAGES:
                result.status = "partial"
                skipped += 1
                continue
            try:
                checked[name] = lookup(name)
            except DependencyLookupError:
                checked[name] = None
                result.status = "partial"
                result.notes.append(f"PyPI freshness unavailable for {name}; no conclusion drawn.")
        latest = checked[name]
        if latest is not None and latest > pin:
            result.findings.append(
                Finding(
                    rule="DEPENDENCY_OUTDATED",
                    severity="low",
                    path=path,
                    line=line,
                    message=f"{name} is pinned to {pin}; PyPI latest stable release is {latest}.",
                    suggestion="Review compatibility and changelogs; update the pin and run tests.",
                )
            )
    result.notes.append(
        f"Considered {pins} exact pins; skipped {skipped} unsupported declarations."
    )
    if skipped:
        result.status = "partial"
    if not raw:
        result.notes.append("No supported dependency declarations were found.")
    return result
