"""Heuristic secret, configuration, and dependency checks."""
