"""Conservative text heuristics; no credential validation or history scanning."""

import re
from pathlib import Path

from devpilot.models import CheckResult, Finding
from devpilot.scanner.project import ScanContext

TEXT_SUFFIXES = frozenset(
    {
        ".py",
        ".pyi",
        ".toml",
        ".ini",
        ".cfg",
        ".json",
        ".yaml",
        ".yml",
        ".txt",
        ".md",
        ".rst",
        ".sh",
        ".ps1",
        ".bat",
        ".js",
        ".ts",
        ".tsx",
        ".jsx",
        ".env",
        ".conf",
        ".properties",
        ".xml",
        ".pem",
        ".key",
        ".dockerfile",
        ".example",
        ".sample",
    }
)
TOKEN = re.compile(
    r"\b(?:AKIA[0-9A-Z]{16}|gh[pousr]_[A-Za-z0-9]{30,}|"
    r"github_pat_[A-Za-z0-9_]{40,}|sk_live_[A-Za-z0-9]{16,})\b"
)
ASSIGNMENT = re.compile(
    r"(?i)[\"']?\b(?:api[_-]?key|secret[_-]?key|client[_-]?secret|"
    r"access[_-]?token|auth[_-]?token|password|passwd|token)[\"']?\s*[:=]\s*"
    r"(?:[\"']([^\"'\r\n]{8,})[\"']|([^\s#;,}{\r\n]{8,}))"
)
PRIVATE_KEY = re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |ENCRYPTED )?PRIVATE KEY-----")
PLACEHOLDER = re.compile(
    r"(?i)^(?:example|sample|dummy|test|fake|your[_-]|replace|change[_-]?me|"
    r"placeholder|redacted|not[_-]?a[_-]?real)|^\$|^<|^\{|^\*+$|^x+$|"
    r"^(?:os\.|getenv\(|environ\[|process\.)"
)
CONFIG_RULES = (
    (
        "CONFIG_DEBUG",
        re.compile(r"(?i)\bDEBUG\s*[:=]\s*(?:True|true|1)\b"),
        "Debug mode appears enabled.",
        "Disable debug mode in production configuration.",
    ),
    (
        "CONFIG_TLS",
        re.compile(r"(?i)\b(?:verify|verify_ssl|ssl_verify)\s*[:=]\s*(?:False|false|0)\b"),
        "TLS certificate verification appears disabled.",
        "Enable certificate verification and configure trusted CAs.",
    ),
    (
        "CONFIG_HOSTS",
        re.compile(r"(?i)\bALLOWED_HOSTS\s*=\s*\[\s*['\"]\*['\"]\s*\]"),
        "Wildcard allowed hosts configuration found.",
        "List the hosts that should serve this application.",
    ),
)


def analyze_security(context: ScanContext) -> CheckResult:
    """Inspect likely text files and identify Git-indexed credential exposure."""
    result = CheckResult(category="security")
    tracked = set(context.inventory.tracked_files)
    result.notes.extend(
        [
            "Heuristics only: findings require review; no findings does not prove safety.",
            "Working tree only; Git-tracked means indexed, not proven committed in history.",
            "No source snippets, secret values, or partial secret previews are stored.",
        ]
    )
    for relative in context.inventory.files:
        path = Path(relative)
        if path.name == ".env" and relative in tracked:
            result.findings.append(
                Finding(
                    rule="SECRET_TRACKED_ENV",
                    severity="high",
                    path=relative,
                    message="A .env file is tracked by Git.",
                    suggestion="Review contents, untrack the file, and rotate exposed secrets.",
                )
            )
        if not (
            path.suffix.lower() in TEXT_SUFFIXES
            or path.name.startswith(".env")
            or path.name in {"Dockerfile", "Makefile", "Pipfile", ".pypirc", ".npmrc", ".netrc"}
        ):
            continue
        text = context.read_text(relative)
        if text is None:
            result.status = "partial"
            continue
        for number, line in enumerate(text.splitlines(), 1):
            matches = list(ASSIGNMENT.finditer(line))
            literal = any(not PLACEHOLDER.search(m.group(1) or m.group(2)) for m in matches)
            if PRIVATE_KEY.search(line) or TOKEN.search(line) or literal:
                result.findings.append(
                    Finding(
                        rule="SECRET_LITERAL",
                        severity="high",
                        path=relative,
                        line=number,
                        message="Secret-like literal detected [REDACTED]."
                        + (" File is tracked by Git." if relative in tracked else ""),
                        suggestion="Review locally; rotate real secrets and use a secret store.",
                    )
                )
            if line.lstrip().startswith(("#", "//", ";")):
                continue
            for rule, pattern, message, suggestion in CONFIG_RULES:
                if pattern.search(line):
                    result.findings.append(
                        Finding(
                            rule=rule,
                            severity="medium",
                            path=relative,
                            line=number,
                            message=message,
                            suggestion=suggestion,
                        )
                    )
    return result
