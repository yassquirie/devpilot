# DevPilot report: sample

Generated: 2026-11-14T00:00:00+00:00 · DevPilot 0.1.0

**Health score: 71/100**

Python project: True · Files: 5 · Python source files: 2 · Content skips: 0

## Project structure

| Root entry | Files |
| --- | ---: |
| LICENSE | 1 |
| README.md | 1 |
| app.py | 1 |
| pyproject.toml | 1 |
| settings.py | 1 |

Configuration files: pyproject.toml

## Scanner (complete)

- **MEDIUM · PROJECT\_NO\_TESTS** — project
  No conventional Python tests found. Add tests/ with pytest tests for the project's public behavior.

## Documentation (complete)

- **LOW · DOC\_CONTRIBUTING** — project
  Contribution guidelines are missing. Add CONTRIBUTING.md with setup, test, lint, and review instructions.

## Quality (complete)

- Ruff E/F rules; isolated configuration, no fixes, source snippets omitted.

- **LOW · RUFF\_F401** — app.py:1
  Ruff detected F401. Remove the unused import or explicitly re-export the public symbol.

## Security (complete)

- Heuristics only: findings require review; no findings does not prove safety.
- Working tree only; Git-tracked means indexed, not proven committed in history.
- No source snippets, secret values, or partial secret previews are stored.
- Dependency freshness not checked \(offline\); opt in with --check-updates.

- **MEDIUM · CONFIG\_DEBUG** — app.py:3
  Debug mode appears enabled. Disable debug mode in production configuration.
- **HIGH · SECRET\_LITERAL** — settings.py:1
  Secret-like literal detected \[REDACTED\]. Review locally; rotate real secrets and use a secret store.

## Scoring

| Category | Earned | Available | Deducted |
| --- | ---: | ---: | ---: |
| scanner | 5 | 10 | 5 |
| documentation | 18 | 20 | 2 |
| quality | 28 | 30 | 2 |
| security | 20 | 40 | 20 |

Budgets: scanner 10, quality 30, security 40, documentation 20. Each finding deducts high=15, medium=5, low=2, info=0 points from its category, capped at that category's budget. Score = floor(100 * earned / available). Skipped categories are excluded. Partial checks retain their budget and make the score provisional; missing coverage never proves health. Scores on different scopes are not comparable. Offline dependency freshness is outside the default score's scope. This is not a security rating.
