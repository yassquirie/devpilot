"""Generate actual reports from a temporary, intentionally unhealthy project."""

from datetime import UTC, datetime
from pathlib import Path
from tempfile import TemporaryDirectory

from devpilot.reporting.render import serialize
from devpilot.service import build_report


def main() -> None:
    """Construct synthetic input outside the source tree and export static examples."""
    output = Path(__file__).parent
    with TemporaryDirectory() as directory:
        root = Path(directory) / "sample"
        root.mkdir()
        (root / "README.md").write_text("# Sample\n\n## Installation\n\npip install .\n")
        (root / "LICENSE").write_text("MIT License\n")
        (root / "pyproject.toml").write_text('[project]\nname="sample"\nversion="0.1.0"\n')
        (root / "app.py").write_text("import os\n\nDEBUG = True\n")
        synthetic = "synthetic-" + "credential-for-example-only"
        (root / "settings.py").write_text('API_KEY = "' + synthetic + '"\n')
        report = build_report(root)
        # Keep committed examples deterministic; actual CLI reports use the current UTC time.
        report.generated_at = datetime(2026, 11, 14, tzinfo=UTC)
        for format, extension in [("json", "json"), ("markdown", "md")]:
            (output / f"report.{extension}").write_text(serialize(report, format), encoding="utf-8")


if __name__ == "__main__":
    main()
