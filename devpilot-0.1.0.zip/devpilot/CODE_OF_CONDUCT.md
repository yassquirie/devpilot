# Code of conduct

DevPilot welcomes contributors of all backgrounds and experience levels. Treat
participants respectfully in issues, reviews, discussions, and project events.

## Expected behavior

- Be considerate, clear, and patient. Critique code and ideas, not people.
- Give useful feedback and accept reasonable feedback in good faith.
- Respect different experiences, identities, accessibility needs, and boundaries.
- Protect others' privacy. Use synthetic examples and do not share credentials.

## Unacceptable behavior

Harassment, discriminatory language, threats, sexual attention, personal attacks,
deliberate disruption, and sharing private information without consent are not
acceptable. Retaliation against someone reporting misconduct is also prohibited.

## Reporting and enforcement

Contact project maintainers privately through the private contact listed on the
hosting repository when one is configured. If none is listed, request a private
contact without naming affected people or posting sensitive details publicly.
Maintainers must establish that contact before opening a public community.

Maintainers will assess reports confidentially to the extent practical, consider
context, and take proportionate action. Responses may include a request to change
behavior, removal of content, a warning, temporary restrictions, or a permanent
ban. Maintainers should explain applicable actions and provide a private way to
appeal. Reports involving a maintainer should go to another maintainer where
available. Do not promise absolute confidentiality when safety or law requires
disclosure.

This policy applies in project spaces and when representing the project publicly.
