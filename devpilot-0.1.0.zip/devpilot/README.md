# DevPilot

**Know what to improve before your next commit.**

DevPilot is a read-only CLI for Python project health. It inventories a repository,
runs Ruff, checks documentation, and flags secret-like literals and risky settings.
Each finding includes a location and a practical next step. Export the same report
as JSON or Markdown for review and CI.

Python **3.11+** · Typer · Rich · Pydantic · Ruff · MIT

> Early release, version 0.1.0. The health score is a maintenance heuristic.
> DevPilot is not a comprehensive security audit, vulnerability database, or proof
> that a project is safe. Review findings in context.

## Installation

From a source checkout, create a virtual environment and install the package:

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1

python -m pip install --upgrade pip
python -m pip install .
devpilot --version
```

For contributor setup, use `python -m pip install -e ".[dev]"` instead.
The distribution name is `devpilot-toolkit`; the executable and Python import are
both `devpilot`. This repository does not claim an existing PyPI publication or
name reservation. A local wheel can also be installed with
`python -m pip install path/to/devpilot_toolkit-0.1.0-py3-none-any.whl`.

See [the installation guide](docs/installation.md) for isolated installation,
Windows commands, building distributions, and troubleshooting.

## Quick start

```bash
devpilot scan .
devpilot quality .
devpilot security .
devpilot report . --format markdown
devpilot report . --format json --output devpilot-report.json
```

`scan` and `report` run the same four analyzers. `scan` defaults to a terminal
report; `report` defaults to Markdown. `quality` and `security` run focused checks
and score only their selected category. Every command accepts `--help`. The module
entry point works too: `python -m devpilot scan .`.

```bash
# Exclude generated code (quote globs so your shell does not expand them).
devpilot scan . --exclude generated --exclude "vendor/*"

# Opt in to public PyPI requests for exact dependency pins.
devpilot security . --check-updates

# Fail a CI step if a medium/high finding is detected.
devpilot scan . --fail-on medium

# Redirect machine-readable JSON: stdout contains only the report.
devpilot report . --format json > devpilot-report.json
```

JSON/Markdown stdout is UTF-8, including under legacy Windows pipe encodings.
`--output` creates a new UTF-8 JSON/Markdown file and refuses to replace an existing
file. Its parent directory must already exist. Use a new name for each report.
No source file is modified, no Ruff fix is applied, and no project code is executed.
The CLI only writes a report when explicitly asked; shell redirection is controlled
by the shell. Avoid redirecting over a source file or a previous report.

## What gets checked

| Area | Checks | Typical action |
| --- | --- | --- |
| Project | Python markers, source count, root structure, configuration files, conventional tests | Declare metadata or add tests |
| Quality | Ruff E/F rules, including F401 unused imports and F821 undefined names | Review the indicated line |
| Security | Known token shapes, sensitive literal assignments, private-key headers, tracked `.env`, debug/TLS/wildcard-host heuristics | Review locally and rotate real exposed credentials |
| Dependencies | Optional PyPI comparison for exact direct pins | Review changelogs and compatibility |
| Documentation | Root `README.md`, installation signals, root license, contribution guide | Add missing onboarding information |

Ruff runs with isolated settings, E/F rules, and a Python 3.11 target; a project's
Ruff configuration is not loaded. Inline `noqa` comments remain effective. Raw Ruff
messages are omitted because they may contain source literals. No snippets,
credential values, or partial credential previews are included in findings.

Read [the check reference](docs/checks.md) for exact behavior, exclusions, limits,
and supported dependency files. [Security limitations](SECURITY.md) describe the
heuristics and their false positives and blind spots.

## Reports and score

Reports show file counts, a compact structure summary, configuration files,
analyzer status, findings, actionable suggestions, and a score breakdown.
JSON includes a versioned schema and UTC generation time.

```text
DevPilot · sample
Health: 71/100
Python: True | Files: 5 | Source: 2

Documentation · complete
LOW  DOC_CONTRIBUTING  Contribution guidelines are missing.
Quality · complete
LOW  RUFF_F401         Ruff detected F401. Remove the unused import...
Security · complete
HIGH SECRET_LITERAL   Secret-like literal detected [REDACTED].
```

This compact display is illustrative; generated reports from a deliberately
unhealthy sample are in [examples/report.md](examples/report.md) and
[examples/report.json](examples/report.json). Reproduce them with
`python examples/generate_reports.py`. The sample uses synthetic values constructed
at runtime, never live credentials.

Scoring is deliberately simple:

| Category | Points available |
| --- | ---: |
| Project scanner | 10 |
| Quality | 30 |
| Security | 40 |
| Documentation | 20 |

Each high finding deducts **15**, medium **5**, low **2**, and informational **0**
points from its category, capped at the category budget. The result is
`floor(100 × earned / available)`. Skipped categories are excluded; partial checks
retain their budget and mark the result **provisional**. A skipped requested check
also makes the result provisional. A focused command's denominator differs from a
full scan, so compare scores only for the same scope and version. No evaluated
categories produces a null score.

Offline dependency freshness is explicitly outside the default scoring scope. An
online failure or unsupported declaration makes an opted-in freshness check
partial. A score of 100 means no penalized findings were detected in the evaluated
scope; it cannot establish software quality or security.

## Exit codes

| Code | Meaning |
| --- | --- |
| `0` | Completed; no enabled severity threshold was exceeded. Check skipped statuses in the report. |
| `1` | Findings meet/exceed `--fail-on` (`low`, `medium`, or `high`). |
| `2` | Invalid arguments, invalid directory, or report write failure. |
| `3` | Incomplete analysis: a requested analyzer was partial. Takes precedence over `1`. The report is still emitted. |

The default `--fail-on none` lets developers inspect findings without failing the
command. CI should choose an explicit policy and treat incomplete analysis
separately from a clean run.

## Contributing

Start with [CONTRIBUTING.md](CONTRIBUTING.md), the
[architecture guide](docs/architecture.md), and the
[code of conduct](CODE_OF_CONDUCT.md). The test suite includes unit tests and CLI
integration tests using real Ruff. Tests do not require network access. Git tests
run when Git is installed; symlink tests may skip on Windows without permission.

```bash
python -m pip install -e ".[dev]"
python -m pytest --cov=devpilot --cov-report=term-missing
python -m ruff check .
python -m ruff format --check .
python -m build
```

Git is optional. DevPilot uses the Git executable for read-only file/index listing
when available and falls back to filesystem traversal otherwise. GitPython is not
needed for these operations, avoiding an unnecessary runtime dependency.

Licensed under the [MIT License](LICENSE).
