# Check reference

## Inventory and scope

Python source counts include `.py` and `.pyi` files, including tests, within the
selected scope. Python markers include `pyproject.toml` project/build metadata,
`setup.py`, `setup.cfg`, `requirements.txt`, Pipfile, and common Python lock files.
Detection is conventional, not semantic; other Python layouts may be missed.

When Git works, inventory is the union of indexed files and nonignored untracked
files returned by `git ls-files`. Thus ignored untracked `.env` files are not
scanned. Tracked files remain eligible even if a Git ignore pattern matches them.
Without Git, filesystem walking applies built-in exclusions and user patterns;
`.gitignore` is not interpreted independently.

In both modes, built-in exclusions remove VCS metadata, virtual environments,
caches, `node_modules`, `build`, `dist`, egg metadata, and coverage HTML. A tracked
file in a built-in excluded directory is excluded too. Symbolic links and linked
directories are not followed. Windows junction targets outside the scan root are
rejected by path resolution. Submodule contents are not recursively audited by
Git-aware inventory. Scan submodules separately.

`--exclude` matches case-sensitive POSIX relative paths or individual path
components with Python `fnmatch` globs. Repeat the flag for multiple patterns.
Excluded files are intentionally out of scope and do not reduce the score.

Default limits: **20,000 in-scope files**, **1,048,576 bytes per text read**, **30
seconds total for Ruff subprocess work**, and **10 seconds per Git listing**. The
inventory keeps oversized file paths and source counts but does not analyze their
contents; it emits coverage warnings. UTF-8/UTF-8 BOM text is supported; undecodable
and NUL-containing candidate files yield partial coverage. Unknown extensions are
inventoried but not checked for secrets. Git listing output and the file-path
inventory are held in memory; this is intended for ordinary developer repositories,
not unbounded or actively hostile filesystems.

## Rule IDs

| Rule | Severity | Detection |
| --- | --- | --- |
| `PROJECT_NOT_PYTHON` | info | No recognized Python markers |
| `PROJECT_NO_TESTS` | medium | Python project without `tests/` Python files, `tests.py`, or `test_*.py` |
| `PROJECT_NO_CONFIG` | low | No recognized Python project/dependency configuration |
| `DOC_README` | medium | No root `README.md` (case-insensitive) |
| `DOC_INSTALL` | low | README lacks an installation/setup/quick-start heading or pip/uv/Poetry install command |
| `DOC_LICENSE` | medium | No root LICENSE/LICENCE/COPYING file, with optional extension |
| `DOC_CONTRIBUTING` | low | No CONTRIBUTING.md in root, `.github/`, or `docs/` |
| `RUFF_<code>` | medium/low | Ruff E/F diagnostic; F821 and invalid syntax are medium, others low |
| `SECRET_LITERAL` | high | Known token shape, private-key header, or suspicious sensitive assignment |
| `SECRET_TRACKED_ENV` | high | Exact `.env` filename in the Git index |
| `CONFIG_DEBUG` | medium | Literal DEBUG enabled |
| `CONFIG_TLS` | medium | Literal verify/verify_ssl/ssl_verify disabled |
| `CONFIG_HOSTS` | medium | `ALLOWED_HOSTS = ["*"]` form |
| `DEPENDENCY_OUTDATED` | low | Opted-in, exact pin lower than verifiable PyPI latest stable release |

Documentation checks find conventional files and signals; they do not determine
license validity, instruction correctness, or overall documentation quality.
Ruff configuration and line length use isolated defaults, not DevPilot's own
development lint configuration. Pytest is used to test DevPilot; scans do not run
the target project's test suite.

## Dependency freshness

`--check-updates` sends normalized package names to `https://pypi.org/pypi/<name>/json`.
No source code, version pins, or credential strings are sent. The endpoint and
metadata fields are documented in the [PyPI JSON API](https://docs.pypi.org/api/json/).
It compares only `info.version`, requires a stable version and at least one
non-yanked distribution file, and does not search all historical releases.

Supported input:

- Root `requirements*.txt`: one PEP 508 requirement per line; whitespace-prefixed
  inline comments are stripped.
- Root `pyproject.toml`: `[project].dependencies` strings.
- Exactly one `==` specifier containing a valid PEP 440 version.

Not resolved: version ranges, wildcard/arbitrary equality pins, markers, URLs,
private indexes, `-r` includes, editable requirements, multiline/hash forms,
optional dependency groups, dynamic dependencies, or lock files. Unsupported
declarations are counted without echoing their text and make opted-in freshness
partial. Empty supported inputs are explicitly noted; the tool does not infer that
no other dependencies exist. No installed environment or transitive dependency
graph is inspected.

At most **20 distinct package names** are queried per report, sequentially, with a
**3-second timeout** per request and a **2 MiB** response cap. Socket timeouts are
per blocking operation, not an overall scan deadline. Names are cached within one
report. Failed, malformed, prerelease-only, or yanked metadata produces no outdated
finding and marks the check partial. A newer release might require a different
Python version or break the project: this is a freshness signal, not an upgrade
recommendation or vulnerability claim.

## Upstream references

- [Ruff configuration and CLI](https://docs.astral.sh/ruff/configuration/)
- [Ruff rule reference](https://docs.astral.sh/ruff/rules/)
- [Typer CLI testing](https://typer.tiangolo.com/tutorial/testing/)
- [PyPI JSON API](https://docs.pypi.org/api/json/)
