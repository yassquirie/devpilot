# Installation and execution

## Requirements

- Python 3.11 or later with pip and venv.
- A local source checkout or the supplied wheel. No published PyPI package is assumed.
- Optional: Git on PATH for `.gitignore` and index awareness.
- Internet access during dependency installation. Scanning is offline by default.

## Windows PowerShell

Open a terminal in the DevPilot source directory:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\python -m pip install --upgrade pip
.venv\Scripts\python -m pip install .
.venv\Scripts\devpilot --help
.venv\Scripts\devpilot scan C:\path\to\your\project
.venv\Scripts\devpilot report C:\path\to\your\project -f json -o health.json
```

Replace `py -3.11` with your installed Python 3.11+ interpreter, for example
`python`. Direct interpreter paths avoid changing PowerShell execution policy or
requiring activation. To activate instead, use `.venv\Scripts\Activate.ps1` if your
local policy permits it, then run `devpilot` directly.

## macOS / Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install .
.venv/bin/devpilot scan /path/to/project
.venv/bin/devpilot report /path/to/project -f markdown -o health.md
```

Or activate with `source .venv/bin/activate` and use `devpilot` on PATH.

## Development

```bash
python -m pip install -e ".[dev]"
python -m pytest
python -m ruff check .
python -m ruff format --check .
```

Run these commands from the repository root. Editable installation connects the
CLI to changes under `src/devpilot/`.

## Build and install a wheel

```bash
python -m pip install -e ".[dev]"
python -m build
python -m pip install dist/devpilot_toolkit-0.1.0-py3-none-any.whl
devpilot --version
```

`python -m build` produces a wheel and a source distribution in `dist/`. A wheel
contains DevPilot itself; pip still needs access to its dependencies (or a local
wheelhouse) on a fresh machine. No repository URL or publication credentials are
required to install from local files.

## Troubleshooting

- **Command not found:** use `python -m devpilot`, activate the environment, or call
  its `Scripts/devpilot` (Windows) / `bin/devpilot` (POSIX) directly.
- **Invalid directory:** pass an existing readable directory, not an individual
  file. Quote paths that contain spaces.
- **Ruff unavailable:** reinstall DevPilot in the environment that runs it. Ruff is
  a required dependency; missing/broken Ruff yields partial coverage and exit `3`.
- **Report already exists:** select a new filename or move the old report yourself.
  DevPilot never overwrites existing reports. The output directory must exist.
- **Exit `3`:** inspect coverage warnings and check notes. Large files, unreadable
  content, file limits, timeouts, malformed TOML, or opted-in network failures may
  make the score provisional. Adjust limits or exclusions deliberately.
- **PyPI inaccessible:** omit `--check-updates` for an offline scan. Failed requests
  produce no freshness claim; no dependency installation is attempted.
- **Different results with/without Git:** Git-aware inventory honors ignore rules;
  filesystem fallback uses only built-in exclusions and `--exclude` patterns.

See `devpilot scan --help` for all options.
