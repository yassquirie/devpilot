# Architecture

DevPilot separates acquisition, analysis, orchestration, and presentation.

```text
src/devpilot/
  models.py             Pydantic report contracts
  service.py            Analyzer orchestration
  scanner/project.py    Inventory, Git listing, bounded UTF-8 reads
  quality/ruff.py       Read-only Ruff subprocess adapter
  security/secrets.py   Secret/configuration heuristics
  security/dependencies.py  Optional PyPI freshness verification
  documentation/analyzer.py  Documentation conventions
  reporting/score.py    Transparent point budgets and deductions
  reporting/render.py  Markdown, JSON, and Rich output
  cli/app.py            Typer arguments, exports, exit codes
tests/                  Unit and CLI integration tests
```

## Data flow

1. The CLI validates format/limit options and asks `service.build_report` to run.
2. `inspect_project` resolves the root, inventories working-tree files, and creates
   a `ScanContext`. Paths exposed in a report are relative POSIX paths.
3. Analyzers read bounded UTF-8 text through the context. They return `CheckResult`
   values containing sanitized findings, actionable suggestions, status, and notes.
4. The service merges dependency observations into the security category, propagates
   coverage warnings, calculates the score, and constructs a versioned `Report`.
5. A renderer consumes that model. The CLI optionally creates a report file and
   selects the exit code after emitting the report.

`Report` never contains raw file contents, snippets, full/partial secret values, or
raw subprocess errors. Do not add such fields. File names and declared dependency
names are still repository metadata; reports may themselves be sensitive.

## Key decisions

- Use standard-library Git subprocess calls, avoiding GitPython for simple listing.
  Commands use argument arrays, no shell, and timeouts. Git's filesystem monitor
  integration is explicitly disabled to avoid running repository-configured
  monitor hooks. The Git executable is resolved before execution and refused if
  it is inside the scanned repository. No history is inspected.
- Use Ruff as the actual lint engine. Fixed isolated E/F rules give consistent
  behavior without executing or trusting repository configuration. Each Python
  file is passed through stdin. Python isolated mode prevents repository-local
  `ruff.py` files and `PYTHONPATH` from shadowing the installed Ruff module.
  Missing/broken Ruff is partial coverage, not a successful empty result.
- Use `packaging` for requirement parsing, normalized names, and PEP 440 comparison;
  lexical version comparisons would give incorrect freshness results.
- Make online checks explicit. Use bounded HTTPS JSON reads and no server response
  text in errors. The checked environment is never installed or resolved.
- Keep output formats on one shared report model. `schema_version` identifies JSON
  compatibility; new breaking report shapes require a new schema version.
- Do not load arbitrary project plugins or execute setup/build files. The scanned
  repository is input data, not application configuration.
- Report errors that prevent checking as coverage gaps. An empty list of findings
  is not sufficient evidence of a successful check.

## Extending DevPilot

Add an analyzer function accepting `ScanContext` and returning `CheckResult`, or
extend an existing category. Findings need a stable rule ID, severity, location
when known, and a concrete action. Keep evidence in local source; never copy its
literal value into findings. Register the analyzer in `service.py`, document scope
and scoring implications, and add behavior-focused tests for positives, negatives,
and failure cases. A new scoring category also requires a documented budget policy.

## Public Python interface

```python
from pathlib import Path
from devpilot.service import build_report

report = build_report(Path("."), mode="scan", online=False)
print(report.score.value)
print(report.model_dump_json(indent=2))
```

The Python interface raises `ScanError` for invalid targets. Analyzer runtime
limitations appear in structured results. Version 0.1.0 is an early API: consumers
should pin a compatible DevPilot version and check the report schema.
